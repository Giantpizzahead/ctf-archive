#!/bin/bash
HISTFILE=~/.bash_history
set -o history

cd /home/secret
zip -P taskdeadlyauditorywoodwork flag.zip flag.txt
rm /home/secret/flag.txt