#!/bin/bash

/opt/setup.sh &
sleep 10
rm /opt/setup.sh
while :; do :; done & kill -STOP $! && wait $!